# btw - version 2 

___

`btw` is an R wrapper for the phylogenetic comparative methods software BayesTraits, which was developed by Mark Pagel and Andrew Meade, and is available from their [website](http://www.evolution.rdg.ac.uk/BayesTraits.html). 

Check my [website](http://rgriff23.github.io/projects/btw.html) for a tutorial on getting started and using `btw` to run BayesTraits from R.

___

