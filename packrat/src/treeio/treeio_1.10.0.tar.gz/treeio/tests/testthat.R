library(testthat)
library(treeio)

test_check("treeio")
